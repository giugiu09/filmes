<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cadastro do Diretor</title>
</head>
<body>
	<h1>Cadastro do Diretor</h1>
	<form action="processa_cad_Diretor.php" method="post">
		Diretor: <input type="text" name="txtDiretor">
		<br><br>
		<input type="submit" value="Cadastrar">
	</form>

</body>
</html>