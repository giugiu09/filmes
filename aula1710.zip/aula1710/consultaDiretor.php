<<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Listagem de Diretor</title>
</head>
<body>

<?php

require_once ("conn.php");

$resultado = mysqli_query($conn,"select * from tbdiretorfilme"); 


echo "<table border=1>";
    echo "<tr>";
        echo "<td>Código</td><td>Diretor</td>";
    echo "</tr>";

    while($linha = mysqli_fetch_array($resultado)) 
    { 
        echo "<tr>";
            echo "<td>";
                echo $linha['codDiretorFilme'];
            echo "</td>";
            echo "<td>";
                echo $linha['nomeDiretor'];
            echo "</td>";
        echo "</tr>";

    }

echo "</table>";
?>
    <a href="index.php">
        <button>
            Voltar
        </button>
    </a>
</body>
</html>