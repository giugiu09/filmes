<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cadastro do Gênero</title>
</head>
<body>
	<h1>Cadastro do Gênero</h1>
	<form action="processa_cad_Genero.php" method="post">
		Gênero: <input type="text" name="txtGenero">
		<br><br>
		<input type="submit" value="Cadastrar">
	</form>

</body>
</html>