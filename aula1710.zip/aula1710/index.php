<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<h1>◄ Aula  26/09/2025 ►</h1>
		<fieldset>
			<legend>Lista de exercícios (FILME)</legend>
			<ul>
				<li><a href="cadAtores.php">Cadastro do Ator</a></li><br>
				<li><a href="cadDiretor.php">Cadastro do Diretor</a></li><br>
				<li><a href="cadGenero.php">Cadastro do Gênero</a></li><br>
				<li><a href="cadastro.php">Cadastro dos Filmes</a></li><br>
				<li><a href="cadAtor.php">Cadastro de Atores nos Filmes</li></a>
			<br>
				<fieldset>
					<li style="list-style: none;"><a href="consultaFilme.php">Listagem Filmes</a></li><br>
					<li style="list-style: none;"><a href="consultaAtor.php">Listagem Atores</a></li><br>
					<li style="list-style: none;"><a href="consultaGenero.php">Listagem Gênero</a></li><br>
					<li style="list-style: none;"><a href="consultaDiretor.php">Listagem Diretores</a></li><br>
				</fieldset>	
			</ul>
		</fieldset>
</body>
</html>